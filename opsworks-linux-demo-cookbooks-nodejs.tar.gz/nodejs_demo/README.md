# Usage

* run `berks package`
* update `cookbooks-*.tar.gz` and set as cookbook source
* create custom layer
* add `nodejs_demo` as recipe in `setup`
* create app, using e.g. https://github.com/awslabs/opsworks-linux-demo-nodejs as a source
* start instance
* goto http://public IP or DNS name of your instance/
